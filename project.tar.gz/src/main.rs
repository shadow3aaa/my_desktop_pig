// Prevents additional console window on Windows in release, DO NOT REMOVE
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod pet;
mod tray;

use bevy::{
    prelude::*,
    render::{
        RenderPlugin,
        settings::{Backends, RenderCreation, WgpuSettings},
    },
    window::{CompositeAlphaMode, PresentMode, WindowLevel, WindowResolution},
};
use pet::{PetPlugin, config};
use tray::TrayPlugin;

fn main() {
    let mut wgpu_settings = WgpuSettings::default();
    wgpu_settings.backends = Some(Backends::VULKAN);

    App::new()
        .add_plugins(
            DefaultPlugins
                .set(ImagePlugin::default_nearest())
                .set(WindowPlugin {
                    primary_window: Some(Window {
                        title: "Piggy".into(),
                        resolution: WindowResolution::new(config::WINDOW_SIZE, config::WINDOW_SIZE)
                            .with_scale_factor_override(1.0),
                        position: WindowPosition::At(config::INITIAL_WINDOW_POSITION),
                        skip_taskbar: true,
                        decorations: false,
                        transparent: true,
                        window_level: WindowLevel::AlwaysOnTop,
                        present_mode: PresentMode::Mailbox,
                        composite_alpha_mode: CompositeAlphaMode::Auto,
                        ..default()
                    }),
                    ..default()
                })
                .set(RenderPlugin {
                    render_creation: RenderCreation::Automatic(wgpu_settings),
                    ..default()
                }),
        )
        .insert_resource(ClearColor(Color::NONE))
        .add_plugins((PetPlugin, TrayPlugin))
        .run();
}
