use bevy::{
    prelude::*,
    window::{PrimaryWindow, WindowPosition},
};

use super::{
    behavior,
    components::{ActivityState, BehaviorController, MoveController, Pet},
    config,
};

pub fn begin_drag(
    mouse_buttons: Res<ButtonInput<MouseButton>>,
    mut primary_window: Single<&mut Window, With<PrimaryWindow>>,
    mut pet: Query<(&mut ActivityState, &mut MoveController), With<Pet>>,
) {
    if !mouse_buttons.just_pressed(MouseButton::Left) {
        return;
    }

    let Ok((mut state, mut movement)) = pet.single_mut() else {
        return;
    };

    *state = ActivityState::Dragged;
    movement.target = None;
    movement.position = current_window_position(&primary_window.position)
        .map(config::window_position_vec2)
        .unwrap_or(movement.position);

    primary_window.start_drag_move();
}

pub fn sync_dragged_position(
    primary_window: Single<&Window, With<PrimaryWindow>>,
    mut pet: Query<(&mut ActivityState, &mut MoveController), With<Pet>>,
) {
    let Ok((state, mut movement)) = pet.single_mut() else {
        return;
    };

    if *state != ActivityState::Dragged {
        return;
    }

    if let Some(position) = current_window_position(&primary_window.position) {
        movement.position = config::window_position_vec2(position);
    }
}

pub fn end_drag(
    mouse_buttons: Res<ButtonInput<MouseButton>>,
    primary_window: Single<&Window, With<PrimaryWindow>>,
    mut pet: Query<
        (
            &mut ActivityState,
            &mut BehaviorController,
            &mut MoveController,
        ),
        With<Pet>,
    >,
) {
    if !mouse_buttons.just_released(MouseButton::Left) {
        return;
    }

    let Ok((mut state, mut behavior_controller, mut movement)) = pet.single_mut() else {
        return;
    };

    if *state != ActivityState::Dragged {
        return;
    }

    if let Some(position) = current_window_position(&primary_window.position) {
        movement.position = config::window_position_vec2(position);
    }

    *state = ActivityState::Idle;
    behavior_controller.state_timer = behavior::random_idle_timer();
}

fn current_window_position(position: &WindowPosition) -> Option<IVec2> {
    match position {
        WindowPosition::At(position) => Some(*position),
        _ => None,
    }
}
