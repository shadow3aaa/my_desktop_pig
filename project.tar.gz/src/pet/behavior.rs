use bevy::{
    prelude::*,
    window::{Monitor, PrimaryMonitor, PrimaryWindow},
};
use rand::RngExt;

use super::{
    components::{ActivityState, AnimationController, BehaviorController, MoveController, Pet},
    config,
};

pub fn tick_behavior(
    time: Res<Time>,
    primary_window: Single<&Window, With<PrimaryWindow>>,
    monitors: Query<&Monitor, With<PrimaryMonitor>>,
    mut pet: Query<
        (
            &mut ActivityState,
            &mut BehaviorController,
            &mut MoveController,
        ),
        With<Pet>,
    >,
) {
    let Ok((mut state, mut behavior, mut movement)) = pet.single_mut() else {
        return;
    };

    match *state {
        ActivityState::Idle => {
            behavior.state_timer.tick(time.delta());

            if !behavior.state_timer.just_finished() {
                return;
            }

            let mut rng = rand::rng();
            if rng.random_bool(config::SLEEP_CHANCE as f64) {
                movement.target = None;
                *state = ActivityState::FallingAsleep;
                return;
            }

            if let Some(target) =
                choose_roam_target(movement.position, *primary_window, monitors.iter().next())
            {
                movement.target = Some(target);
                *state = ActivityState::Walking;
            } else {
                behavior.state_timer = random_idle_timer();
            }
        }
        ActivityState::Sleeping => {
            behavior.state_timer.tick(time.delta());

            if behavior.state_timer.just_finished() {
                *state = ActivityState::WakingUp;
            }
        }
        ActivityState::Walking
        | ActivityState::Dragged
        | ActivityState::FallingAsleep
        | ActivityState::WakingUp => {}
    }
}

pub fn random_idle_timer() -> Timer {
    let mut rng = rand::rng();
    let seconds = rng.random_range(config::IDLE_DURATION_MIN..=config::IDLE_DURATION_MAX);
    Timer::from_seconds(seconds, TimerMode::Once)
}

pub fn random_sleep_timer() -> Timer {
    let mut rng = rand::rng();
    let seconds = rng.random_range(config::SLEEP_DURATION_MIN..=config::SLEEP_DURATION_MAX);
    Timer::from_seconds(seconds, TimerMode::Once)
}

pub fn advance_sleep_state(
    mut pet: Query<
        (
            &mut ActivityState,
            &mut BehaviorController,
            &mut AnimationController,
        ),
        With<Pet>,
    >,
) {
    let Ok((mut state, mut behavior, mut animation)) = pet.single_mut() else {
        return;
    };

    match *state {
        ActivityState::FallingAsleep if animation.just_completed => {
            *state = ActivityState::Sleeping;
            behavior.state_timer = random_sleep_timer();
            animation.just_completed = false;
        }
        ActivityState::WakingUp if animation.just_completed => {
            *state = ActivityState::Idle;
            behavior.state_timer = random_idle_timer();
            animation.just_completed = false;
        }
        _ => {}
    }
}

fn choose_roam_target(current: Vec2, window: &Window, monitor: Option<&Monitor>) -> Option<Vec2> {
    let bounds = roam_bounds(current, window, monitor)?;
    let mut rng = rand::rng();

    Some(Vec2::new(
        rng.random_range(bounds.min.x..=bounds.max.x),
        rng.random_range(bounds.min.y..=bounds.max.y),
    ))
}

fn roam_bounds(current: Vec2, window: &Window, monitor: Option<&Monitor>) -> Option<Rect> {
    let monitor = monitor?;
    let window_width = window.physical_width() as f32;
    let window_height = window.physical_height() as f32;
    let padding = config::SCREEN_PADDING as f32;

    let min_x = monitor.physical_position.x as f32 + padding;
    let min_y = monitor.physical_position.y as f32 + padding;
    let max_x =
        monitor.physical_position.x as f32 + monitor.physical_width as f32 - window_width - padding;
    let max_y = monitor.physical_position.y as f32 + monitor.physical_height as f32
        - window_height
        - padding;

    if max_x <= min_x || max_y <= min_y {
        return None;
    }

    Some(Rect::from_corners(
        Vec2::new(
            (current.x - config::ROAM_RADIUS).clamp(min_x, max_x),
            (current.y - config::ROAM_RADIUS).clamp(min_y, max_y),
        ),
        Vec2::new(
            (current.x + config::ROAM_RADIUS).clamp(min_x, max_x),
            (current.y + config::ROAM_RADIUS).clamp(min_y, max_y),
        ),
    ))
}
