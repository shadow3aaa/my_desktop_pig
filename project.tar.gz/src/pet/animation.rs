use std::collections::HashMap;

use bevy::prelude::*;

use super::{
    components::{ActivityState, AnimationController, Facing, Pet, PetAnimation},
    config,
};

#[derive(Resource, Default)]
pub struct AnimationLibrary {
    clips: HashMap<PetAnimation, AnimationClip>,
}

impl AnimationLibrary {
    pub fn insert(&mut self, animation: PetAnimation, clip: AnimationClip) {
        self.clips.insert(animation, clip);
    }

    pub fn clip(&self, animation: PetAnimation) -> &AnimationClip {
        self.clips
            .get(&animation)
            .or_else(|| self.clips.get(&PetAnimation::Idle))
            .expect("AnimationLibrary must contain an idle clip")
    }
}

#[derive(Clone)]
pub struct AnimationClip {
    pub image: Handle<Image>,
    pub layout: Handle<TextureAtlasLayout>,
    pub start: usize,
    pub end: usize,
    pub fps: f32,
    pub repeat: bool,
}

pub fn setup_animation_library(
    mut commands: Commands,
    asset_server: Res<AssetServer>,
    mut atlas_layouts: ResMut<Assets<TextureAtlasLayout>>,
) {
    let mut library = AnimationLibrary::default();

    // Register clips here. Each animation may point at a different sprite sheet,
    // which lets us swap between walk / fall asleep / sleep loop / wake up atlases later.
    let walk_image = asset_server.load(config::WALK_SHEET_PATH);
    let walk_layout = atlas_layouts.add(TextureAtlasLayout::from_grid(
        UVec2::splat(config::WALK_FRAME_SIZE),
        config::WALK_ATLAS_COLUMNS,
        config::WALK_ATLAS_ROWS,
        None,
        None,
    ));
    let sleep_layout = atlas_layouts.add(TextureAtlasLayout::from_grid(
        UVec2::splat(config::SLEEP_FRAME_SIZE),
        config::SLEEP_ATLAS_COLUMNS,
        config::SLEEP_ATLAS_ROWS,
        None,
        None,
    ));

    library.insert(
        PetAnimation::Idle,
        AnimationClip {
            image: walk_image.clone(),
            layout: walk_layout.clone(),
            start: config::IDLE_FRAME,
            end: config::IDLE_FRAME,
            fps: 1.0,
            repeat: true,
        },
    );

    library.insert(
        PetAnimation::Walk,
        AnimationClip {
            image: walk_image,
            layout: walk_layout,
            start: config::WALK_START_FRAME,
            end: config::WALK_END_FRAME,
            fps: config::WALK_FPS,
            repeat: true,
        },
    );
    library.insert(
        PetAnimation::FallAsleep,
        AnimationClip {
            image: asset_server.load(config::FALL_ASLEEP_SHEET_PATH),
            layout: sleep_layout.clone(),
            start: config::FALL_ASLEEP_START_FRAME,
            end: config::FALL_ASLEEP_END_FRAME,
            fps: config::FALL_ASLEEP_FPS,
            repeat: false,
        },
    );
    library.insert(
        PetAnimation::SleepLoop,
        AnimationClip {
            image: asset_server.load(config::SLEEP_LOOP_SHEET_PATH),
            layout: sleep_layout.clone(),
            start: config::SLEEP_LOOP_START_FRAME,
            end: config::SLEEP_LOOP_END_FRAME,
            fps: config::SLEEP_LOOP_FPS,
            repeat: true,
        },
    );
    library.insert(
        PetAnimation::WakeUp,
        AnimationClip {
            image: asset_server.load(config::WAKE_UP_SHEET_PATH),
            layout: sleep_layout,
            start: config::WAKE_UP_START_FRAME,
            end: config::WAKE_UP_END_FRAME,
            fps: config::WAKE_UP_FPS,
            repeat: false,
        },
    );

    commands.insert_resource(library);
}

pub fn sync_animation_state(
    library: Res<AnimationLibrary>,
    mut query: Query<
        (
            &ActivityState,
            &Facing,
            &mut AnimationController,
            &mut Sprite,
        ),
        With<Pet>,
    >,
) {
    for (state, facing, mut controller, mut sprite) in &mut query {
        let next_animation = animation_for_state(*state);

        if controller.current != next_animation {
            controller.current = next_animation;
            apply_clip(&mut controller, &mut sprite, library.clip(next_animation));
        }

        sprite.flip_x = matches!(facing, Facing::Right);
    }
}

pub fn advance_animation(
    time: Res<Time>,
    library: Res<AnimationLibrary>,
    mut query: Query<(&mut AnimationController, &mut Sprite), With<Pet>>,
) {
    for (mut controller, mut sprite) in &mut query {
        let clip = library.clip(controller.current);
        controller.just_completed = false;

        if clip.start == clip.end {
            if let Some(atlas) = &mut sprite.texture_atlas {
                atlas.index = clip.start;
            }
            continue;
        }

        controller.timer.tick(time.delta());

        if !controller.timer.just_finished() {
            continue;
        }

        if let Some(atlas) = &mut sprite.texture_atlas {
            if atlas.index >= clip.end {
                atlas.index = if clip.repeat { clip.start } else { clip.end };
                if !clip.repeat {
                    controller.just_completed = true;
                }
            } else {
                atlas.index += 1;
                if !clip.repeat && atlas.index >= clip.end {
                    controller.just_completed = true;
                }
            }
        }
    }
}

fn animation_for_state(state: ActivityState) -> PetAnimation {
    match state {
        ActivityState::Idle | ActivityState::Dragged => PetAnimation::Idle,
        ActivityState::Walking => PetAnimation::Walk,
        ActivityState::FallingAsleep => PetAnimation::FallAsleep,
        ActivityState::Sleeping => PetAnimation::SleepLoop,
        ActivityState::WakingUp => PetAnimation::WakeUp,
    }
}

fn apply_clip(controller: &mut AnimationController, sprite: &mut Sprite, clip: &AnimationClip) {
    controller.timer = animation_timer(clip);
    controller.just_completed = false;
    sprite.image = clip.image.clone();
    sprite.texture_atlas = Some(TextureAtlas {
        layout: clip.layout.clone(),
        index: clip.start,
    });
}

fn animation_timer(clip: &AnimationClip) -> Timer {
    Timer::from_seconds(1.0 / clip.fps, TimerMode::Repeating)
}
