use bevy::{
    prelude::*,
    window::{PrimaryWindow, WindowPosition},
};

use super::{
    behavior,
    components::{ActivityState, BehaviorController, Facing, MoveController, Pet},
    config,
};

pub fn move_pet(
    time: Res<Time>,
    mut primary_window: Single<&mut Window, With<PrimaryWindow>>,
    mut pet: Query<
        (
            &mut ActivityState,
            &mut BehaviorController,
            &mut MoveController,
            &mut Facing,
        ),
        With<Pet>,
    >,
) {
    let Ok((mut state, mut behavior, mut movement, mut facing)) = pet.single_mut() else {
        return;
    };

    if *state != ActivityState::Walking {
        return;
    }

    let Some(target) = movement.target else {
        *state = ActivityState::Idle;
        behavior.state_timer = behavior::random_idle_timer();
        return;
    };

    let to_target = target - movement.position;
    let distance = to_target.length();

    if distance <= config::ARRIVAL_DISTANCE {
        movement.position = target;
        movement.target = None;
        *state = ActivityState::Idle;
        behavior.state_timer = behavior::random_idle_timer();
        primary_window.position = WindowPosition::At(window_position(movement.position));
        return;
    }

    let direction = to_target / distance;
    let step = movement.speed * time.delta_secs();
    movement.position += direction * step.min(distance);

    if direction.x > 0.01 {
        *facing = Facing::Right;
    } else if direction.x < -0.01 {
        *facing = Facing::Left;
    }

    primary_window.position = WindowPosition::At(window_position(movement.position));
}

fn window_position(position: Vec2) -> IVec2 {
    IVec2::new(position.x.round() as i32, position.y.round() as i32)
}
