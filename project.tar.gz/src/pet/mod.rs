pub mod animation;
pub mod behavior;
pub mod components;
pub mod config;
pub mod interaction;
pub mod movement;

use animation::AnimationLibrary;
use bevy::prelude::*;
use components::{
    ActivityState, AnimationController, BehaviorController, Facing, MoveController, Pet,
    PetAnimation,
};

pub struct PetPlugin;

impl Plugin for PetPlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(
            Startup,
            (animation::setup_animation_library, spawn_pet).chain(),
        )
        .add_systems(
            Update,
            (
                interaction::begin_drag,
                interaction::sync_dragged_position,
                interaction::end_drag,
                behavior::tick_behavior,
                movement::move_pet,
                animation::sync_animation_state,
                animation::advance_animation,
                behavior::advance_sleep_state,
            )
                .chain(),
        );
    }
}

fn spawn_pet(mut commands: Commands, library: Res<AnimationLibrary>) {
    commands.spawn(Camera2d::default());

    let idle_clip = library.clip(PetAnimation::Idle);

    commands.spawn((
        Pet,
        ActivityState::Idle,
        Facing::Right,
        BehaviorController::new(behavior::random_idle_timer()),
        MoveController::new(
            config::INITIAL_WINDOW_POSITION.as_vec2(),
            config::WALK_SPEED,
        ),
        AnimationController::idle(),
        Sprite::from_atlas_image(
            idle_clip.image.clone(),
            TextureAtlas {
                layout: idle_clip.layout.clone(),
                index: idle_clip.start,
            },
        ),
    ));
}
