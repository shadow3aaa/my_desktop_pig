use bevy::prelude::*;

#[derive(Component)]
pub struct Pet;

#[derive(Component, Clone, Copy, Debug, PartialEq, Eq)]
pub enum ActivityState {
    Idle,
    Walking,
    Dragged,
    FallingAsleep,
    Sleeping,
    WakingUp,
}

#[derive(Component, Clone, Copy, Debug, PartialEq, Eq)]
pub enum Facing {
    Left,
    Right,
}

#[derive(Component)]
pub struct BehaviorController {
    pub state_timer: Timer,
}

impl BehaviorController {
    pub fn new(state_timer: Timer) -> Self {
        Self { state_timer }
    }
}

#[derive(Component)]
pub struct MoveController {
    pub position: Vec2,
    pub target: Option<Vec2>,
    pub speed: f32,
}

impl MoveController {
    pub fn new(position: Vec2, speed: f32) -> Self {
        Self {
            position,
            target: None,
            speed,
        }
    }
}

#[derive(Component)]
pub struct AnimationController {
    pub current: PetAnimation,
    pub timer: Timer,
    pub just_completed: bool,
}

impl AnimationController {
    pub fn new(current: PetAnimation, timer: Timer) -> Self {
        Self {
            current,
            timer,
            just_completed: false,
        }
    }

    pub fn idle() -> Self {
        Self::new(
            PetAnimation::Idle,
            Timer::from_seconds(1.0, TimerMode::Repeating),
        )
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum PetAnimation {
    Idle,
    Walk,
    #[allow(dead_code)]
    FallAsleep,
    #[allow(dead_code)]
    SleepLoop,
    #[allow(dead_code)]
    WakeUp,
}
