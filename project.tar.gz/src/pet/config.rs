use bevy::{math::IVec2, prelude::*};

pub const WINDOW_SIZE: u32 = 120;
pub const WALK_SHEET_PATH: &str = "walk.png";
pub const WALK_FRAME_SIZE: u32 = 100;
pub const WALK_ATLAS_COLUMNS: u32 = 3;
pub const WALK_ATLAS_ROWS: u32 = 3;
pub const FALL_ASLEEP_SHEET_PATH: &str = "fall_asleep.png";
pub const SLEEP_LOOP_SHEET_PATH: &str = "sleep_loop.png";
pub const WAKE_UP_SHEET_PATH: &str = "wake_up.png";
pub const SLEEP_FRAME_SIZE: u32 = 100;
pub const SLEEP_ATLAS_COLUMNS: u32 = 3;
pub const SLEEP_ATLAS_ROWS: u32 = 3;
pub const WALK_START_FRAME: usize = 0;
pub const WALK_END_FRAME: usize = 8;
pub const IDLE_FRAME: usize = 4;
pub const WALK_FPS: f32 = 10.0;
pub const FALL_ASLEEP_START_FRAME: usize = 0;
pub const FALL_ASLEEP_END_FRAME: usize = 8;
pub const FALL_ASLEEP_FPS: f32 = 10.0;
pub const SLEEP_LOOP_START_FRAME: usize = 0;
pub const SLEEP_LOOP_END_FRAME: usize = 8;
pub const SLEEP_LOOP_FPS: f32 = 8.0;
pub const WAKE_UP_START_FRAME: usize = 0;
pub const WAKE_UP_END_FRAME: usize = 8;
pub const WAKE_UP_FPS: f32 = 10.0;
pub const INITIAL_WINDOW_POSITION: IVec2 = IVec2::new(100, 100);
pub const WALK_SPEED: f32 = 120.0;
pub const ARRIVAL_DISTANCE: f32 = 4.0;
pub const ROAM_RADIUS: f32 = 220.0;
pub const SCREEN_PADDING: i32 = 16;
pub const IDLE_DURATION_MIN: f32 = 1.5;
pub const IDLE_DURATION_MAX: f32 = 3.5;
pub const SLEEP_CHANCE: f32 = 0.3;
pub const SLEEP_DURATION_MIN: f32 = 4.0;
pub const SLEEP_DURATION_MAX: f32 = 8.0;

pub fn window_position_vec2(position: IVec2) -> Vec2 {
    Vec2::new(position.x as f32, position.y as f32)
}
