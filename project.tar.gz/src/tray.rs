use bevy::{app::AppExit, prelude::*};

#[cfg(target_os = "windows")]
use image::ImageFormat;
#[cfg(target_os = "windows")]
use tray_icon::{
    Icon, TrayIcon, TrayIconBuilder,
    menu::{Menu, MenuEvent, MenuId, MenuItem},
};

pub struct TrayPlugin;

impl Plugin for TrayPlugin {
    fn build(&self, app: &mut App) {
        #[cfg(target_os = "windows")]
        app.add_systems(Startup, setup_tray)
            .add_systems(Update, handle_tray_menu_events);
    }
}

#[cfg(target_os = "windows")]
struct TrayState {
    _tray_icon: TrayIcon,
    quit_id: MenuId,
}

#[cfg(target_os = "windows")]
const TRAY_ICON_PNG: &[u8] =
    include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"), "/icons/32x32.png"));

#[cfg(target_os = "windows")]
fn setup_tray(world: &mut World) {
    world.insert_non_send_resource(create_tray_state());
}

#[cfg(target_os = "windows")]
fn handle_tray_menu_events(
    tray_state: Option<NonSend<TrayState>>,
    mut app_exit: MessageWriter<AppExit>,
) {
    let Some(tray_state) = tray_state else {
        return;
    };

    while let Ok(event) = MenuEvent::receiver().try_recv() {
        if event.id == tray_state.quit_id {
            app_exit.write(AppExit::Success);
        }
    }
}

#[cfg(target_os = "windows")]
fn create_tray_state() -> TrayState {
    let icon = load_tray_icon();
    let menu = Menu::new();
    let quit_item = MenuItem::new("退出", true, None);
    menu.append(&quit_item)
        .expect("failed to append quit item to tray menu");

    let tray_icon = TrayIconBuilder::new()
        .with_tooltip("Piggy")
        .with_menu(Box::new(menu))
        .with_icon(icon)
        .build()
        .expect("failed to create tray icon");

    TrayState {
        _tray_icon: tray_icon,
        quit_id: quit_item.id().clone(),
    }
}

#[cfg(target_os = "windows")]
fn load_tray_icon() -> Icon {
    let image = image::load_from_memory_with_format(TRAY_ICON_PNG, ImageFormat::Png)
        .expect("failed to decode tray icon png")
        .into_rgba8();
    let (width, height) = image.dimensions();

    Icon::from_rgba(image.into_raw(), width, height).expect("failed to create tray icon rgba")
}
